import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";

// Offerwall data structure
interface OfferwallOffer {
  id: string;
  title: string;
  description: string;
  reward: number;
  timeMinutes: number;
  type: 'survey' | 'game' | 'video' | 'offer';
  provider: 'cpx' | 'bitlabs' | 'theorem' | 'adgem' | 'lootably';
  difficulty: 'easy' | 'medium' | 'hard';
  imageUrl?: string;
}

// Sample offers data
const surveyOffers: OfferwallOffer[] = [
  {
    id: 'cpx-survey-1',
    title: 'Consumer Shopping Habits',
    description: 'Share your shopping preferences',
    reward: 250,
    timeMinutes: 5,
    type: 'survey',
    provider: 'cpx',
    difficulty: 'easy'
  },
  {
    id: 'bitlabs-survey-1',
    title: 'Technology Usage Survey',
    description: 'Help improve tech products',
    reward: 300,
    timeMinutes: 7,
    type: 'survey',
    provider: 'bitlabs',
    difficulty: 'medium'
  },
  {
    id: 'theorem-survey-1',
    title: 'Health & Wellness Study',
    description: 'Participate in wellness research',
    reward: 400,
    timeMinutes: 8,
    type: 'survey',
    provider: 'theorem',
    difficulty: 'medium'
  },
  {
    id: 'cpx-survey-2',
    title: 'Food Preferences Survey',
    description: 'Share your food choices',
    reward: 200,
    timeMinutes: 4,
    type: 'survey',
    provider: 'cpx',
    difficulty: 'easy'
  },
  {
    id: 'bitlabs-survey-2',
    title: 'Entertainment Preferences',
    description: 'Rate your entertainment choices',
    reward: 350,
    timeMinutes: 6,
    type: 'survey',
    provider: 'bitlabs',
    difficulty: 'easy'
  }
];

const gameVideoOffers: OfferwallOffer[] = [
  {
    id: 'adgem-game-1',
    title: 'Play Puzzle Game',
    description: 'Complete 10 levels',
    reward: 500,
    timeMinutes: 15,
    type: 'game',
    provider: 'adgem',
    difficulty: 'medium'
  },
  {
    id: 'lootably-video-1',
    title: 'Watch Product Videos',
    description: 'View 5 product demonstrations',
    reward: 150,
    timeMinutes: 10,
    type: 'video',
    provider: 'lootably',
    difficulty: 'easy'
  },
  {
    id: 'adgem-game-2',
    title: 'Strategy Game Challenge',
    description: 'Reach level 5 in strategy game',
    reward: 600,
    timeMinutes: 20,
    type: 'game',
    provider: 'adgem',
    difficulty: 'hard'
  },
  {
    id: 'lootably-video-2',
    title: 'Watch Tutorial Videos',
    description: 'Complete video series',
    reward: 180,
    timeMinutes: 8,
    type: 'video',
    provider: 'lootably',
    difficulty: 'easy'
  },
  {
    id: 'adgem-offer-1',
    title: 'Download & Try App',
    description: 'Install and use app for 2 minutes',
    reward: 300,
    timeMinutes: 5,
    type: 'offer',
    provider: 'adgem',
    difficulty: 'easy'
  }
];

// Provider logos and colors
const providerConfig = {
  cpx: { name: 'CPX Research', color: 'bg-blue-500', textColor: 'text-blue-700' },
  bitlabs: { name: 'BitLabs', color: 'bg-purple-500', textColor: 'text-purple-700' },
  theorem: { name: 'TheoremReach', color: 'bg-green-500', textColor: 'text-green-700' },
  adgem: { name: 'AdGem', color: 'bg-orange-500', textColor: 'text-orange-700' },
  lootably: { name: 'Lootably', color: 'bg-red-500', textColor: 'text-red-700' }
};

interface OfferCardProps {
  offer: OfferwallOffer;
  onComplete: (offer: OfferwallOffer) => void;
}

function OfferCard({ offer, onComplete }: OfferCardProps) {
  const provider = providerConfig[offer.provider];
  
  return (
    <Card className="min-w-[280px] flex-shrink-0 hover:shadow-lg transition-shadow duration-300 border-l-4" 
          style={{ borderLeftColor: provider.color.replace('bg-', '#') }}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-sm font-semibold line-clamp-2">{offer.title}</CardTitle>
          <Badge className={`${provider.color} text-white text-xs`}>
            +{offer.reward}
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-600">
          <span className={`px-2 py-1 rounded ${provider.textColor} bg-gray-100`}>
            {provider.name}
          </span>
          <span>• {offer.timeMinutes} min</span>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-xs text-gray-600 mb-3 line-clamp-2">{offer.description}</p>
        <div className="flex justify-between items-center">
          <Badge variant="outline" className="text-xs">
            {offer.difficulty}
          </Badge>
          <Button 
            size="sm" 
            className="text-xs px-3 py-1 h-8"
            onClick={() => onComplete(offer)}
          >
            Start
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

interface ScrollingSectionProps {
  title: string;
  offers: OfferwallOffer[];
  direction: 'left' | 'right';
  icon: React.ReactNode;
  onOfferComplete: (offer: OfferwallOffer) => void;
}

function ScrollingSection({ title, offers, direction, icon, onOfferComplete }: ScrollingSectionProps) {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-4">
        {icon}
        <h2 className="text-xl font-bold text-gray-800">{title}</h2>
        <Badge variant="secondary" className="ml-auto">
          {offers.length} available
        </Badge>
      </div>
      
      <div className="relative overflow-hidden">
        <div 
          className={`flex gap-4 animate-scroll-${direction}`}
          style={{
            animationDuration: '30s',
            animationIterationCount: 'infinite',
            animationTimingFunction: 'linear'
          }}
        >
          {/* Duplicate offers for seamless scrolling */}
          {[...offers, ...offers].map((offer, index) => (
            <OfferCard 
              key={`${offer.id}-${index}`} 
              offer={offer} 
              onComplete={onOfferComplete}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

interface OfferwallSectionsProps {
  onOfferComplete: (offer: OfferwallOffer, reward: number) => void;
}

export function OfferwallSections({ onOfferComplete }: OfferwallSectionsProps) {
  const { user } = useAuth();

  const handleOfferClick = (offer: OfferwallOffer) => {
    if (!user) return;
    
    // Simulate offerwall completion
    // In real implementation, this would redirect to the offerwall provider
    const reward = offer.reward;
    
    // Simulate completing the offer after a delay
    setTimeout(() => {
      onOfferComplete(offer, reward);
    }, 2000);
  };

  return (
    <div className="space-y-8">
      {/* Games & Videos Section - Scrolling Left */}
      <ScrollingSection
        title="Games & Videos"
        offers={gameVideoOffers}
        direction="left"
        icon={
          <div className="flex">
            <svg className="w-6 h-6 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
              <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM14 11a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0v-1h-1a1 1 0 110-2h1v-1a1 1 0 011-1z" />
            </svg>
          </div>
        }
        onOfferComplete={handleOfferClick}
      />

      {/* Surveys Section - Scrolling Right */}
      <ScrollingSection
        title="Surveys"
        offers={surveyOffers}
        direction="right"
        icon={
          <div className="flex">
            <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
            </svg>
          </div>
        }
        onOfferComplete={handleOfferClick}
      />
    </div>
  );
}

// CSS animations for scrolling
const scrollAnimationCSS = `
@keyframes scroll-left {
  0% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(-50%);
  }
}

@keyframes scroll-right {
  0% {
    transform: translateX(-50%);
  }
  100% {
    transform: translateX(0);
  }
}

.animate-scroll-left {
  animation: scroll-left 30s linear infinite;
}

.animate-scroll-right {
  animation: scroll-right 30s linear infinite;
}
`;

// Inject CSS
if (typeof document !== 'undefined') {
  const style = document.createElement('style');
  style.textContent = scrollAnimationCSS;
  document.head.appendChild(style);
}

export type { OfferwallOffer };