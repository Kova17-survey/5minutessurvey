import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

interface WithdrawalPanelProps {
  user: any;
  pendingWithdrawal: any;
  onWithdrawalSuccess: () => void;
}

export function WithdrawalPanel({ user, pendingWithdrawal, onWithdrawalSuccess }: WithdrawalPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [amount, setAmount] = useState("");
  const [walletAddress, setWalletAddress] = useState("");

  const withdrawalMutation = useMutation({
    mutationFn: (data: { amount: number; walletAddress: string }) =>
      apiRequest("POST", "/api/withdrawals", data),
    onSuccess: () => {
      toast({
        title: "Withdrawal Requested",
        description: "Your withdrawal request has been submitted for admin review.",
      });
      setAmount("");
      setWalletAddress("");
      onWithdrawalSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message || "Failed to submit withdrawal request.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const numAmount = parseInt(amount);
    
    if (!numAmount || numAmount < 100) {
      toast({
        title: "Invalid Amount",
        description: "Minimum withdrawal amount is 100 gems.",
        variant: "destructive",
      });
      return;
    }

    if (numAmount > user.gemBalance) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough gems for this withdrawal.",
        variant: "destructive",
      });
      return;
    }

    if (!walletAddress.trim()) {
      toast({
        title: "Wallet Address Required",
        description: "Please enter your Litecoin wallet address.",
        variant: "destructive",
      });
      return;
    }

    withdrawalMutation.mutate({
      amount: numAmount,
      walletAddress: walletAddress.trim(),
    });
  };

  const estimatedValue = (user.gemBalance * 0.05).toFixed(2);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Withdraw Earnings</CardTitle>
        <p className="text-sm text-gray-600">Convert gems to Litecoin</p>
      </CardHeader>
      
      <CardContent>
        <div className="text-center mb-6">
          <div className="inline-flex items-center bg-secondary/10 px-4 py-2 rounded-full mb-2">
            <svg className="w-4 h-4 text-secondary mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
            </svg>
            <span className="text-2xl font-bold text-gray-900">{user.gemBalance}</span>
            <span className="text-sm text-gray-600 ml-1">gems</span>
          </div>
          <p className="text-sm text-gray-600">≈ ${estimatedValue} LTC</p>
        </div>

        {pendingWithdrawal ? (
          <div className="p-3 bg-accent/10 rounded-lg border border-accent/20">
            <div className="flex items-center">
              <svg className="w-4 h-4 text-accent mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
              </svg>
              <span className="text-sm font-medium text-gray-700">Withdrawal Pending</span>
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Your request for {pendingWithdrawal.amount} gems is under review
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="amount">Withdrawal Amount</Label>
              <div className="relative mt-1">
                <Input
                  id="amount"
                  type="number"
                  placeholder="Enter gem amount"
                  min="100"
                  max={user.gemBalance}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  <svg className="w-4 h-4 text-secondary" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Minimum withdrawal: 100 gems</p>
            </div>

            <div>
              <Label htmlFor="wallet">Litecoin Wallet Address</Label>
              <Input
                id="wallet"
                type="text"
                placeholder="Enter your LTC wallet address"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                className="mt-1"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full"
              disabled={withdrawalMutation.isPending}
            >
              {withdrawalMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Processing...
                </>
              ) : (
                "Request Withdrawal"
              )}
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
