import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

interface OfferwallProvider {
  id: string;
  name: string;
  description: string;
  color: string;
  textColor: string;
  estimatedEarnings: string;
  isActive: boolean;
}

const offerwallProviders: OfferwallProvider[] = [
  {
    id: 'cpx',
    name: 'CPX Research',
    description: 'High-quality consumer surveys',
    color: 'bg-blue-500',
    textColor: 'text-blue-700',
    estimatedEarnings: '$2-5/hour',
    isActive: true
  },
  {
    id: 'bitlabs',
    name: 'BitLabs',
    description: 'Surveys, games, and offers',
    color: 'bg-purple-500',
    textColor: 'text-purple-700',
    estimatedEarnings: '$3-6/hour',
    isActive: true
  },
  {
    id: 'theorem',
    name: 'TheoremReach',
    description: 'Mobile-optimized surveys',
    color: 'bg-green-500',
    textColor: 'text-green-700',
    estimatedEarnings: '$2-4/hour',
    isActive: true
  },
  {
    id: 'adgem',
    name: 'AdGem',
    description: 'Games, videos, and app installs',
    color: 'bg-orange-500',
    textColor: 'text-orange-700',
    estimatedEarnings: '$1-3/hour',
    isActive: true
  },
  {
    id: 'lootably',
    name: 'Lootably',
    description: 'Video offers and surveys',
    color: 'bg-red-500',
    textColor: 'text-red-700',
    estimatedEarnings: '$1-2/hour',
    isActive: true
  }
];

interface OfferwallIframeProps {
  onClose: () => void;
  onEarningsUpdate: (amount: number) => void;
}

export function OfferwallIframe({ onClose, onEarningsUpdate }: OfferwallIframeProps) {
  const { user } = useAuth();
  const [selectedProvider, setSelectedProvider] = useState<OfferwallProvider | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const generateOfferwallUrl = (provider: OfferwallProvider): string => {
    if (!user) return '';

    const userId = user.id;
    const baseUrls = {
      cpx: `https://offers.cpx-research.com/index.php?app_id=YOUR_CPX_APP_ID&ext_user_id=${userId}`,
      bitlabs: `https://web.bitlabs.ai/?uid=${userId}&token=YOUR_BITLABS_TOKEN`,
      theorem: `https://theoremreach.com/rewards?api_key=YOUR_THEOREM_API_KEY&user_id=${userId}`,
      adgem: `https://wall.adgemoffers.com/?placementId=YOUR_ADGEM_PLACEMENT_ID&userId=${userId}`,
      lootably: `https://wall.lootably.com/?placementID=YOUR_LOOTABLY_PLACEMENT_ID&subID=${userId}`
    };

    return baseUrls[provider.id as keyof typeof baseUrls] || '';
  };

  const handleProviderSelect = (provider: OfferwallProvider) => {
    setSelectedProvider(provider);
    setIsLoading(true);
    
    // Simulate loading time
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  };

  const handleBackToProviders = () => {
    setSelectedProvider(null);
    setIsLoading(false);
  };

  if (selectedProvider) {
    return (
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl h-[90vh] p-0">
          <DialogHeader className="p-4 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleBackToProviders}
                >
                  ← Back
                </Button>
                <DialogTitle className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${selectedProvider.color}`} />
                  {selectedProvider.name}
                </DialogTitle>
              </div>
              <Badge variant="outline">
                {selectedProvider.estimatedEarnings}
              </Badge>
            </div>
          </DialogHeader>
          
          <div className="flex-1 relative">
            {isLoading ? (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-50">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" />
                  <p className="text-gray-600">Loading {selectedProvider.name}...</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Setting up your personalized offers
                  </p>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center bg-gray-50">
                <div className="text-center max-w-md">
                  <div className={`w-16 h-16 ${selectedProvider.color} rounded-full mx-auto mb-4 flex items-center justify-center`}>
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{selectedProvider.name} Offerwall</h3>
                  <p className="text-gray-600 mb-4">{selectedProvider.description}</p>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                    <p className="text-sm text-yellow-800">
                      <strong>Demo Mode:</strong> In production, this would display the actual {selectedProvider.name} offerwall iframe with live offers.
                    </p>
                  </div>
                  <div className="space-y-2 text-sm text-gray-600">
                    <p>• Complete surveys and offers to earn gems</p>
                    <p>• Earnings range: {selectedProvider.estimatedEarnings}</p>
                    <p>• Rewards credited instantly</p>
                  </div>
                  <Button 
                    className="mt-4" 
                    onClick={() => {
                      // Simulate earning some gems
                      const earnedGems = Math.floor(Math.random() * 500) + 100;
                      onEarningsUpdate(earnedGems);
                      onClose();
                    }}
                  >
                    Simulate Earning Gems
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Choose Offerwall Provider</DialogTitle>
          <p className="text-gray-600">
            Select an offerwall to start earning gems through surveys, games, and offers
          </p>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {offerwallProviders.map((provider) => (
            <Card 
              key={provider.id}
              className={`cursor-pointer transition-all duration-200 hover:shadow-lg border-l-4 ${
                provider.isActive ? 'hover:bg-gray-50' : 'opacity-50 cursor-not-allowed'
              }`}
              style={{ borderLeftColor: provider.color.replace('bg-', '#') }}
              onClick={() => provider.isActive && handleProviderSelect(provider)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${provider.color}`} />
                    {provider.name}
                  </CardTitle>
                  {provider.isActive ? (
                    <Badge className={`${provider.color} text-white`}>
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary">
                      Coming Soon
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm mb-3">{provider.description}</p>
                <div className="flex justify-between items-center">
                  <span className={`text-sm font-medium ${provider.textColor}`}>
                    {provider.estimatedEarnings}
                  </span>
                  {provider.isActive && (
                    <Button size="sm" variant="outline">
                      Open →
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">How it works:</h4>
          <div className="text-sm text-blue-800 space-y-1">
            <p>1. Choose an offerwall provider above</p>
            <p>2. Complete surveys, play games, or watch videos</p>
            <p>3. Earn gems instantly (1000 gems = $1 USD)</p>
            <p>4. Withdraw to Litecoin or Amazon gift cards</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}